from django.shortcuts import render,redirect
from .form import employeeforms
from .models import register
# Create your views here.
def employeelist(request):
    context={'employeelist':register.objects.all()}
    return render(request,'list.html',context)

def employeeform(request,id=0):
    if request.method=="GET":
        if id==0:
            form=employeeforms()
        else:

            employee=register.objects.get(pk=id)
            form=employeeforms(instance=employee)
        return render(request, 'form.html', {'form': form})
    else:
        if id==0:
            form=employeeforms(request.POST)
        else:
            employee=register.objects.get(pk=id)
            form=employeeforms(request.POST,instance=employee)
        if form.is_valid():
              form.save()
        return redirect('employeelist')

def employeedelete(request,id):
    employee=register.objects.get(pk=id)
    employee.delete()
    return redirect('employeelist')
