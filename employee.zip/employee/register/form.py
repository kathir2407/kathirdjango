from django import forms

from .models import register

class employeeforms(forms.ModelForm):
    class Meta:
        model=register
        fields =('fullname','empcode','mobile','positions')
        labels={
            'fullname':'Fullname',
            'empcode':'Emp.code'
        }
        
    def __init__(self,*args,**kwargs):
        super(employeeforms, self).__init__(*args,**kwargs)
        self.fields['positions'].empty_label='select'
        self.fields['empcode'].required=False
